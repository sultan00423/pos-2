const { app, BrowserWindow, Menu, shell, ipcMain } = require('electron');
const path = require('path'), fs = require('fs'), os = require('os');
let autoUpdater = null;
try { autoUpdater = require('electron-updater').autoUpdater; } catch (e) {}
if (!app.requestSingleInstanceLock()) app.quit();
let win;
function create() {
  const icon = path.join(__dirname, 'build', 'icon.png');
  win = new BrowserWindow({ width: 1366, height: 820, show: false, autoHideMenuBar: true, icon, title: 'Bhatti POS',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, devTools: false } });
  Menu.setApplicationMenu(null);
  win.maximize();
  win.loadFile(path.join(__dirname, 'app', 'index.html'));
  win.once('ready-to-show', () => win.show());
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url)) { shell.openExternal(url); return { action: 'deny' }; }
    return { action: 'deny' };
  });
}
// Windows focus bug: after alert/confirm, inputs stop accepting keys. Re-focus the window.
ipcMain.on('refocus', () => { if (win) { win.blur(); win.focus(); win.webContents.focus(); } });
// Print in the background (no new tab/window). Silent to default printer; falls back to the print dialog.
ipcMain.on('print-html', (e, html) => {
  const f = path.join(os.tmpdir(), 'bhatti-print-' + Date.now() + '.html');
  fs.writeFileSync(f, html, 'utf8');
  const pw = new BrowserWindow({ show: false, webPreferences: { contextIsolation: true } });
  pw.loadFile(f);
  pw.webContents.once('did-finish-load', () => setTimeout(() => {
    pw.webContents.print({ silent: true, printBackground: true, margins: { marginType: 'none' } }, ok => {
      if (!ok) pw.webContents.print({ silent: false, printBackground: true }, () => pw.close());
      else pw.close();
    });
  }, 300));
  pw.on('closed', () => fs.unlink(f, () => {}));
});
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.whenReady().then(() => {
  create();
  if (app.isPackaged && autoUpdater) { autoUpdater.on('error', () => {}); autoUpdater.checkForUpdatesAndNotify().catch(() => {}); }
});
app.on('window-all-closed', () => app.quit());
