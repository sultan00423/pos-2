const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('electronAPI', {
  print: html => ipcRenderer.send('print-html', html),
  refocus: () => ipcRenderer.send('refocus'),
});
